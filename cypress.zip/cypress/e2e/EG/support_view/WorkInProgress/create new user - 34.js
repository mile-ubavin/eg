/// <reference types="Cypress" />

describe("crate user from SW", () => {
  // Generate a 3-character random string
  function generateRandomString(length) {
    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let randomString = "";
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      randomString += characters.charAt(randomIndex);
    }
    return randomString;
  }

  // Generate a 5-character random string
  let randomString = generateRandomString(3); // Setup the number of random chracters
  console.log(randomString);
  const username = "TestUser - " + randomString;
  const email = randomString + "-testuser@yopmail.com";

  it("create user from SW", () => {
    // cy.loginToSupportViewAdmin(); //SupportView - using custom commands
    // //Optional
    // cy.wait(1000);
    // cy.get(".mat-mdc-select-placeholder")
    //   .invoke("text")
    //   .then((selectedLanguage) => {
    //     if (selectedLanguage === "English" || selectedLanguage === "Deutsch") {
    //       // Code to execute depending on the selected language
    //       cy.log(selectedLanguage);
    //       //Verify button title depending on transalte (Users/Eng)
    //       cy.get(":nth-child(8) > .mdc-button > .mdc-button__label")
    //         .invoke("text")
    //         .then((buttonText) => {
    //           buttonText.includes("View person") ||
    //             buttonText.includes("Benutzer");

    //           cy.log("Button title is 'View person' or 'Benutzer'");
    //           // Add additional assertions or actions if needed
    //         }); //Verify button title depending on transalte
    //       cy.get(":nth-child(8) > .mdc-button > .mdc-button__label").click(); //Click on Users button
    //       cy.get(".button-wraper > .mdc-button > .mdc-button__label").click(); //Click on Create user button
    //       cy.get(":nth-child(1) > .button__footer > .button__icon").click();
    //       // Fill the Creation user form
    //       cy.get('[formControlName="salutation"]').click();
    //       cy.get("#mat-option-2").click();
    //       //FirstName label
    //       //cy.get("mat-mdc-form-field-label-0")
    //       cy.get("#mat-input-0").type("FirstName");
    //       cy.get("#mat-input-1").type("LastName");
    //       //acc number
    //       cy.get("#mat-input-12").type(username);
    //       cy.get("#mat-input-2").type(email);

    //       //prefix dropdown
    //       cy.get("#mat-select-value-7 > .mat-mdc-select-placeholder").click();
    //       cy.wait(1500);
    //       cy.get(".mdc-list-item__primary-text").click();

    //       //tel
    //       // cy.get("#mat-input-3").type("43");
    //       // cy.get("#mat-input-4").type("64");
    //       // cy.get("#mat-input-5").type("7077777");

    //       //address
    //       cy.get("#mat-input-6").type("Main street");
    //       cy.get("#mat-input-7").type("17");
    //       cy.get("#mat-input-8").type("7");
    //       cy.get("#mat-input-9").type("8010");
    //       cy.get("#mat-input-10").type("Wien");
    //       //title
    //       cy.get("#mat-input-11").type("Test Title");

    //       //Click on Confirm button
    //       cy.get('button[type="submit"]').click();
    //       //Download credentials
    //       cy.get(".download-bttn").click();

    //Yopmail

    // Visit yopmail application or login page
    cy.visit("https://yopmail.com/en/");
    cy.get("#login").type("xuq-testuser@yopmail.com");
    cy.get("#refreshbut > .md > .material-icons-outlined").click();
    // cy.iframe("#ifinbox")
    //   .find(".mctn > .m > button > .lms")
    //   .first()
    //   .should("include.text", "Ihr neuer Benutzer im e-Gehaltszettel Portal"); //Validate subject of Verification email
    // let initialUrl;
    // cy.iframe("#ifmail")
    //   .find(
    //     "#mail>div>div:nth-child(2)>div:nth-child(3)>table>tbody>tr>td>p:nth-child(2)>span>a"
    //   )
    //   .should("include.text", "Jetzt E-Mail Adresse bestätigen")
    //   .invoke("attr", "href")
    //   .then((href) => {
    //     // Log link text
    //     cy.log(`The href attribute is: ${href}`);
    //   });
    // cy.iframe("#ifmail")
    //   .find(
    //     "#mail>div>div:nth-child(2)>div:nth-child(3)>table>tbody>tr>td>p:nth-child(2)>span>a"
    //   )
    //   .invoke("attr", "target", "_self") //prevent opening in new tab
    //   .click();
    // cy.wait(4000);
    // cy.iframe("#ifmail")
    //   .find("#onetrust-accept-btn-handler")
    //   .should("exist")
    //   .click(); // if exist, Remove Cookie bar
    // cy.iframe("#ifmail").find(".button").click();
    // cy.wait(3000);

    //Pasword email

    cy.iframe("#ifinbox")
      .find(".mctn > .m > button > .lms")
      .first()
      .should("include.text", "Passwort zurücksetzen e-Gehaltszettel Portal"); //Validate subject of Verification email
    // let initialUrl;
    // cy.iframe("#ifmail")
    // .find(
    //   "#mail>div>div:nth-child(2)>div:nth-child(3)>table>tbody>tr>td>p:nth-child(2)>span>a"
    // )
    // .should("include.text", "Jetzt E-Mail Adresse bestätigen")

    //   }
    // });
  });
});
